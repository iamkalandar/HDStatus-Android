package com.hdstatus.app

import android.content.ContentValues
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.os.Bundle
import android.view.Gravity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.res.ColorStateList
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var verticalOption: CheckBox
    private lateinit var splitOption: CheckBox
    private lateinit var compressOption: CheckBox
    private lateinit var saveGalleryOption: CheckBox
    private lateinit var convertButton: Button
    private var selectedUri: Uri? = null
    private var selectedMusicUri: Uri? = null
    private var transformer: Transformer? = null
    private var isConverting = false
    private val outputFiles = mutableListOf<File>()
    private var segments = mutableListOf<Pair<Long, Long>>()
    private var currentSegment = 0
    private var durationMs = 0L
    private var sourceWidth = 1280
    private var sourceHeight = 720
    private var sourceBitrate = 8_000_000
    private var requestedBitrate = 8_000_000
    private var useVertical = false

    private val musicPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            selectedMusicUri = uri
            status.text = "Audio file selected. This build does not yet mix it into the exported video."
        }
    }

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            outputFiles.clear()
            status.text = "Video selected. Quality mode requests a bitrate based on source metadata and keeps the original frame size unless 9:16 is enabled. Re-encoding can still lose detail."
        } else {
            status.text = "No video selected."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val navy = Color.rgb(12, 22, 43)
        val blue = Color.rgb(46, 110, 245)
        val ink = Color.rgb(25, 38, 60)
        val muted = Color.rgb(104, 119, 141)
        val canvas = Color.rgb(244, 247, 252)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        window.decorView.systemUiVisibility = 0

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
            setBackgroundColor(canvas)
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(canvas)
            clipToPadding = false
            addView(page)
        }

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
            background = rounded(navy, 24)
        }
        val brandLine = TextView(this).apply {
            text = "HD  •  STATUS STUDIO"
            textSize = 12f
            setTextColor(Color.rgb(151, 190, 255))
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            letterSpacing = 0.12f
        }
        val title = TextView(this).apply {
            text = "Make every frame\\nstatus-ready."
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(12), 0, dp(8))
        }
        val subtitle = TextView(this).apply {
            text = "Prepare crisp videos for WhatsApp Status."
            textSize = 14f
            setTextColor(Color.rgb(205, 216, 235))
        }
        hero.addView(brandLine, matchWrap())
        hero.addView(title, matchWrap())
        hero.addView(subtitle, matchWrap())

        status = TextView(this).apply {
            text = "Start by choosing a video from your phone."
            textSize = 14f
            setTextColor(ink)
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.WHITE, 14, Color.rgb(225, 232, 242))
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            progressTintList = ColorStateList.valueOf(blue)
            visibility = ProgressBar.GONE
        }

        verticalOption = CheckBox(this).apply {
            text = "Vertical 9:16"
            textSize = 14f
            setTextColor(ink)
            isChecked = false
            buttonTintList = ColorStateList.valueOf(blue)
        }
        splitOption = CheckBox(this).apply {
            text = "Split long videos into 60-second clips"
            textSize = 14f
            setTextColor(ink)
            isChecked = true
            buttonTintList = ColorStateList.valueOf(blue)
        }
        compressOption = CheckBox(this).apply {
            text = "Smaller file (may reduce clarity)"
            textSize = 14f
            setTextColor(ink)
            isChecked = false
            buttonTintList = ColorStateList.valueOf(blue)
        }
        saveGalleryOption = CheckBox(this).apply {
            text = "Save converted video to Gallery"
            textSize = 14f
            setTextColor(ink)
            isChecked = true
            buttonTintList = ColorStateList.valueOf(blue)
        }

        val chooseButton = makeButton("1   Choose video", blue, Color.WHITE) {
            if (!isConverting) picker.launch("video/*")
        }
        convertButton = makeButton("2   Convert video", navy, Color.WHITE) { beginConversion() }
        val musicButton = makeButton("Add background music", Color.rgb(232, 239, 250), ink) {
            if (!isConverting) musicPicker.launch(arrayOf("audio/*"))
        }
        val freeMusicButton = makeButton("Explore free music", Color.rgb(232, 239, 250), ink) {
            android.app.AlertDialog.Builder(this@MainActivity)
                .setTitle("Free music for videos")
                .setItems(arrayOf("Pixabay Music", "YouTube Audio Library", "Mixkit Music")) { _, which ->
                    val url = when (which) {
                        0 -> "https://pixabay.com/music/"
                        1 -> "https://www.youtube.com/audiolibrary"
                        else -> "https://mixkit.co/free-stock-music/"
                    }
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }.show()
        }
        val shareButton = makeButton("Share converted clips", Color.rgb(232, 239, 250), ink) { shareOutputs() }
        val aboutButton = TextView(this).apply {
            text = "About HD Status  ·  Contact developer"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(dp(12), dp(18), dp(12), dp(8))
            setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("About HD Status")
                    .setMessage(
                        "HD Status\\nVideo converter for WhatsApp Status\\n\\n" +
                            "Developer: Kalander\\nContact: +91-8050152388\\n\\n" +
                            "Conversion runs on your phone. Supported formats depend on device codecs."
                    )
                    .setPositiveButton("OK", null)
                    .setNeutralButton("WhatsApp contact") { _, _ ->
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/918050152388")))
                    }
                    .show()
            }
        }

        page.addView(hero, matchWrap())
        page.addView(sectionLabel("YOUR VIDEO", muted), withTop(matchWrap(), 20))
        page.addView(chooseButton, withTop(matchWrap(), 8))
        page.addView(sectionLabel("EXPORT SETTINGS", muted), withTop(matchWrap(), 20))

        val settingsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = rounded(Color.WHITE, 18, Color.rgb(228, 234, 243))
        }
        listOf(verticalOption, splitOption, compressOption, saveGalleryOption).forEachIndexed { index, view ->
            settingsCard.addView(view, matchWrap())
            if (index < 3) {
                val divider = android.view.View(this).apply { setBackgroundColor(Color.rgb(238, 242, 248)) }
                settingsCard.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
        page.addView(settingsCard, withTop(matchWrap(), 8))
        page.addView(convertButton, withTop(matchWrap(), 14))
        page.addView(progress, withTop(matchWrap(), 12))
        page.addView(status, withTop(matchWrap(), 12))
        page.addView(sectionLabel("MORE TOOLS", muted), withTop(matchWrap(), 22))
        page.addView(musicButton, withTop(matchWrap(), 8))
        page.addView(freeMusicButton, withTop(matchWrap(), 8))
        page.addView(shareButton, withTop(matchWrap(), 8))
        page.addView(aboutButton, withTop(matchWrap(), 8))
        setContentView(scroll)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeColor != null) setStroke(dp(1), strokeColor)
        }

    private fun withTop(params: LinearLayout.LayoutParams, topDp: Int): LinearLayout.LayoutParams =
        params.apply { topMargin = dp(topDp) }

    private fun sectionLabel(label: String, color: Int) = TextView(this).apply {
        text = label
        textSize = 11f
        setTextColor(color)
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        letterSpacing = 0.12f
    }

    private fun makeButton(label: String, backgroundColor: Int, textColor: Int, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setTextColor(textColor)
            background = rounded(backgroundColor, 14)
            minHeight = dp(52)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            stateListAnimator = null
            setOnClickListener { action() }
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun beginConversion() {
        val input = selectedUri
        if (input == null) {
            status.text = "Please choose a video first."
            return
        }
        if (isConverting) return

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, input)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            sourceWidth = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: 1280
            sourceHeight = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: 720
            // Estimate the source bitrate from metadata, then request a modest headroom.
            // This avoids needlessly starving a good source while avoiding extreme bitrate
            // requests that some Android hardware encoders silently clamp.
            val maxDimension = maxOf(sourceWidth, sourceHeight)
            val detectedBitrate = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
                ?.toIntOrNull()
                ?.takeIf { it > 0 }
            val resolutionCeiling = when {
                maxDimension >= 3000 -> 24_000_000
                maxDimension >= 1900 -> 16_000_000
                maxDimension >= 1200 -> 10_000_000
                maxDimension >= 700 -> 6_000_000
                else -> 3_500_000
            }
            val qualityFloor = when {
                maxDimension >= 3000 -> 12_000_000
                maxDimension >= 1900 -> 7_000_000
                maxDimension >= 1200 -> 3_500_000
                maxDimension >= 700 -> 2_000_000
                else -> 1_000_000
            }
            val resolutionDefault = when {
                maxDimension >= 3000 -> 16_000_000
                maxDimension >= 1900 -> 9_000_000
                maxDimension >= 1200 -> 5_000_000
                maxDimension >= 700 -> 3_000_000
                else -> 1_800_000
            }
            sourceBitrate = if (detectedBitrate != null) {
                (detectedBitrate * 1.20).toInt().coerceIn(qualityFloor, resolutionCeiling)
            } else {
                resolutionDefault.coerceIn(qualityFloor, resolutionCeiling)
            }
        } catch (_: Exception) {
            durationMs = 0L
        } finally {
            try { retriever.release() } catch (_: Exception) { }
        }
        if (durationMs <= 0L) {
            status.text = "Could not read this video's duration. Try another video."
            return
        }

        val outputDir = File(filesDir, "converted")
        if (!outputDir.exists() && !outputDir.mkdirs()) {
            status.text = "Could not create output folder."
            return
        }
        outputFiles.clear()
        segments.clear()
        useVertical = verticalOption.isChecked
        requestedBitrate = if (compressOption.isChecked) (sourceBitrate * 0.60).toInt().coerceAtLeast(900_000) else sourceBitrate
        val segmentLength = 60_000L
        if (splitOption.isChecked && durationMs > segmentLength) {
            var start = 0L
            while (start < durationMs) {
                val end = minOf(start + segmentLength, durationMs)
                segments.add(start to end)
                start = end
            }
        } else {
            segments.add(0L to durationMs)
        }
        currentSegment = 0
        isConverting = true
        convertButton.isEnabled = false
        progress.visibility = ProgressBar.VISIBLE
        progress.progress = 0
        exportNext(input, outputDir)
    }

    private fun exportNext(input: Uri, outputDir: File) {
        if (currentSegment >= segments.size) {
            isConverting = false
            convertButton.isEnabled = true
            progress.progress = 100
            progress.visibility = ProgressBar.GONE
            if (saveGalleryOption.isChecked) {
                saveOutputsToGallery()
            } else {
                status.text = "Export complete: ${outputFiles.size} clip(s). Files remain inside HD Status. Requested video bitrate: ${requestedBitrate / 1_000_000.0} Mbps."
            }
            return
        }

        val (startMs, endMs) = segments[currentSegment]
        val file = File(outputDir, "HDStatus_${System.currentTimeMillis()}_${currentSegment + 1}.mp4")
        val mediaItem = MediaItem.Builder()
            .setUri(input)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
            )
            .build()
        val videoEffects = if (useVertical) {
            listOf(Presentation.createForAspectRatio(9f / 16f, Presentation.LAYOUT_SCALE_TO_FIT))
        } else {
            emptyList()
        }
        val editedItem = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                outputFiles.add(file)
                currentSegment++
                progress.progress = (currentSegment * 100) / segments.size
                status.text = "Converted clip $currentSegment of ${segments.size}…"
                exportNext(input, outputDir)
            }

            override fun onError(
                composition: androidx.media3.transformer.Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                transformer = null
                isConverting = false
                convertButton.isEnabled = true
                file.delete()
                progress.visibility = ProgressBar.GONE
                status.text = "Conversion failed on clip ${currentSegment + 1}. Try a different video."
                Toast.makeText(this@MainActivity, exportException.errorCodeName, Toast.LENGTH_LONG).show()
            }
        }
        try {
            status.text = "Converting clip ${currentSegment + 1} of ${segments.size}…"
            val encoderFactory = DefaultEncoderFactory.Builder(this)
                .setRequestedVideoEncoderSettings(
                    VideoEncoderSettings.Builder()
                        .setBitrate(requestedBitrate)
                        .build()
                )
                .build()
            transformer = Transformer.Builder(this)
                .setEncoderFactory(encoderFactory)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(listener)
                .build()
            transformer?.start(editedItem, file.absolutePath)
        } catch (e: Exception) {
            transformer = null
            isConverting = false
            convertButton.isEnabled = true
            file.delete()
            status.text = "Could not start conversion. Try another video."
        }
    }


    private fun saveOutputsToGallery() {
        val files = outputFiles.filter { it.exists() }
        if (files.isEmpty()) {
            status.text = "Conversion finished, but no output files were found."
            return
        }
        var saved = 0
        var failed = 0
        for (file in files) {
            var insertedUri: Uri? = null
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HD Status")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }
                insertedUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Gallery could not create a media entry")
                contentResolver.openOutputStream(insertedUri, "w").use { output ->
                    if (output == null) throw IllegalStateException("Could not open Gallery destination")
                    file.inputStream().use { input -> input.copyTo(output) }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    contentResolver.update(insertedUri, done, null, null)
                }
                saved++
            } catch (_: Exception) {
                failed++
                if (insertedUri != null) {
                    try { contentResolver.delete(insertedUri, null, null) } catch (_: Exception) { }
                }
            }
        }
        status.text = when {
            saved == files.size -> "Conversion complete. Saved $saved video(s) to Gallery → Movies/HD Status."
            saved > 0 -> "Saved $saved of ${files.size} video(s) to Gallery. Some could not be saved."
            else -> "Conversion complete, but Gallery save failed. Use Share Converted Clips to access your videos."
        }
        if (failed > 0) Toast.makeText(this, "Gallery save failed for $failed file(s).", Toast.LENGTH_LONG).show()
    }

    private fun shareOutputs() {
        val files = outputFiles.filter { it.exists() }
        if (files.isEmpty()) {
            status.text = "Convert a video first."
            return
        }
        try {
            val uris = ArrayList(files.map {
                FileProvider.getUriForFile(this, "$packageName.fileprovider", it)
            })
            val intent = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, uris[0])
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "video/mp4"
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                }
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "Share to WhatsApp or another app"))
        } catch (_: Exception) {
            status.text = "Could not open the share menu."
        }
    }

    override fun onDestroy() {
        if (isConverting) {
            transformer?.cancel()
            transformer = null
        }
        super.onDestroy()
    }
}
