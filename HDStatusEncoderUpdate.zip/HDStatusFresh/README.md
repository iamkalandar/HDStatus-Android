# HD Status Android Project

- App name: HD Status
- Developer: Kalander
- Package: `com.hdstatus.app`
- Contact: +91-8050152388
- Language: Kotlin
- APK: built by GitHub Actions

## Included in this source build

- Select a video from Android's file picker.
- Export MP4 with H.264 video and AAC audio using Android Media3 Transformer.
- Optional 9:16 presentation mode. It is off by default to avoid unnecessary scaling.
- Optional automatic splitting into 60-second clips.
- Share exported clips using Android's share sheet, including WhatsApp when installed.
- No watermark is added by this app.
- Contact details in About screen.

## Important scope note

This is a working starter version, not yet a complete feature-for-feature PureStatus replica. A full photo enhancement pipeline, timeline editor, text/sticker overlays, music mixing, and a dedicated quality/compression selector still require implementation and device testing. MP4 re-encoding can change quality; no app can restore detail absent from the source.

## Build on GitHub using only your phone

1. Open `https://github.com/new` in Chrome and create a **public or private** repository named `HDStatus-Android`. Leave **Add a README** unchecked.
2. Download and extract this ZIP on your phone if your browser/file manager supports it.
3. Open the new repository in Chrome. Choose **Add file → Upload files**. Upload the *contents* of the extracted `HDStatusFresh` folder, not the ZIP itself. Keep the `.github` folder and its `workflows` subfolder. If GitHub mobile hides upload options, use Chrome's **Desktop site**.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab and select **Build HD Status APK**. Wait for the run to finish with a green check.
6. Open that successful run, scroll to **Artifacts**, and download `HD-Status-debug-apk`.
7. Extract the artifact ZIP and tap `app-debug.apk`. If Android prompts, allow Chrome or your file manager to install unknown apps, then install.

## Build details

The workflow builds `app/build/outputs/apk/debug/app-debug.apk` and uploads it as an artifact. Debug APKs are for testing; publishing to Play Store requires a properly signed release build.


## Music option status
This update adds a local audio-file picker and shortcuts to Pixabay Music, YouTube Audio Library, and Mixkit. **Important:** selecting music does not yet mix it into the exported video. Audio mixing and volume controls still require a later implementation and build/test cycle. Use tracks only when their license permits your intended use.


## Quality-oriented export update
This version requests a video bitrate based on the source dimensions and does not add a 720p resize when vertical mode is disabled. Media3/device encoders may adjust the requested bitrate. This reduces avoidable re-encoding loss where possible; it does not perform AI sharpening or restore detail missing from the source. Any re-encoding can still cause some quality loss.


## HD encoder update
- Requests H.264/AAC output with a bitrate selected from source dimensions. The device encoder may not honor the exact requested bitrate.
- Keeps source dimensions when 9:16 mode is off. Enabling 9:16 changes the presentation and can add bars; it does not magically improve detail.
- Splits long videos into 60-second segments. Since Media3 re-encodes clips, this is not guaranteed lossless stream-copy splitting.
- Optional smaller-file mode requests a lower bitrate and may reduce detail.
- Audio picker and free-music website shortcuts are present, but **mixing the selected music into the export is not implemented in this build**.
- This is not AI upscaling or deblurring. A higher bitrate cannot recover details missing from a blurry source. Test on actual devices and compare WhatsApp uploads.
