package com.hdstatus.app

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var verticalOption: CheckBox
    private lateinit var splitOption: CheckBox
    private lateinit var compressOption: CheckBox
    private lateinit var saveGalleryOption: CheckBox
    private lateinit var convertButton: Button
    private var selectedUri: Uri? = null
    private var selectedMusicUri: Uri? = null
    private var transformer: Transformer? = null
    private var isConverting = false
    private val outputFiles = mutableListOf<File>()
    private var segments = mutableListOf<Pair<Long, Long>>()
    private var currentSegment = 0
    private var durationMs = 0L
    private var sourceWidth = 1280
    private var sourceHeight = 720
    private var sourceBitrate = 8_000_000
    private var requestedBitrate = 8_000_000
    private var useVertical = false
    private val galleryUris = mutableListOf<Uri>()
    private lateinit var galleryGrid: GridLayout

    private val musicPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            selectedMusicUri = uri
            status.text = "Audio file selected. This build does not yet mix it into the exported video."
        }
    }

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            outputFiles.clear()
            status.text = "Video selected. Quality mode requests a bitrate based on source metadata and keeps the original frame size unless 9:16 is enabled. Re-encoding can still lose detail."
        } else {
            status.text = "No video selected."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val bg = Color.rgb(12, 13, 16)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(2), dp(4), dp(2), dp(4))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            addView(page)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(14))
            background = rounded(Color.rgb(18, 19, 23), 0, Color.rgb(54, 55, 60))
        }
        header.addView(TextView(this).apply {
            text = "HD Status"
            textSize = 34f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        header.addView(TextView(this).apply {
            text = "☰"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setOnClickListener { showAppMenu() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        page.addView(header, matchWrap())

        val galleryLabel = TextView(this).apply {
            text = "YOUR VIDEOS"
            textSize = 11f
            letterSpacing = .12f
            setTextColor(Color.rgb(164, 169, 180))
            setPadding(dp(10), dp(12), dp(10), dp(8))
        }
        page.addView(galleryLabel, matchWrap())
        galleryGrid = GridLayout(this).apply {
            columnCount = 4
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        page.addView(galleryGrid, matchWrap())

        val emptyHint = TextView(this).apply {
            text = "Choose a video to add it to your workspace."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(dp(18), dp(22), dp(18), dp(22))
            setOnClickListener { picker.launch("video/*") }
        }
        page.addView(emptyHint, matchWrap())
        val prepare = Button(this).apply {
            text = "Prepare / Convert selected video"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(48, 104, 236), 14)
            setOnClickListener {
                if (selectedUri == null) picker.launch("video/*") else buildConverterScreen()
            }
        }
        page.addView(prepare, LinearLayout.LayoutParams(-1, dp(54)).apply {
            setMargins(dp(10), dp(8), dp(10), dp(8))
        })
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(Color.rgb(27, 28, 34), 24, Color.rgb(60, 61, 68))
        }
        listOf("▣\nVideo", "▧\nPhoto", "▤\nAlbums", "✦\nAI").forEachIndexed { index, label ->
            nav.addView(TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(if (index == 0) Color.rgb(84, 139, 255) else Color.LTGRAY)
                setPadding(dp(2), dp(5), dp(2), dp(5))
                setOnClickListener {
                    when(index) {
                        0 -> refreshGallery()
                        1 -> Toast.makeText(this@MainActivity, "Photo preparation is not implemented yet.", Toast.LENGTH_SHORT).show()
                        2 -> Toast.makeText(this@MainActivity, "Albums view is coming next.", Toast.LENGTH_SHORT).show()
                        else -> Toast.makeText(this@MainActivity, "AI tools are not implemented yet.", Toast.LENGTH_SHORT).show()
                    }
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        page.addView(nav, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(dp(10), dp(8), dp(10), dp(10))
        })
        status = TextView(this).apply {
            text = "Select a video thumbnail, or use the button above."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.GRAY)
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        page.addView(status, matchWrap())
        setContentView(scroll)
        refreshGallery()
    }

    private fun refreshGallery() {
        if (!::galleryGrid.isInitialized) return
        galleryGrid.removeAllViews()
        galleryUris.clear()
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(permission) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(permission), 201)
            return
        }
        try {
            val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION)
            contentResolver.query(collection, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { cursor ->
                val idIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durationIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                var count = 0
                while (cursor.moveToNext() && count < 120) {
                    val id = cursor.getLong(idIndex)
                    val name = cursor.getString(nameIndex) ?: "Video"
                    val duration = cursor.getLong(durationIndex)
                    val uri = Uri.withAppendedPath(collection, id.toString())
                    galleryUris.add(uri)
                    galleryGrid.addView(makeVideoTile(uri, name, duration), GridLayout.LayoutParams().apply {
                        width = 0
                        height = dp(112)
                        columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                        setMargins(dp(1), dp(1), dp(1), dp(1))
                    })
                    count++
                }
            }
        } catch (_: Exception) {
            status.text = "Could not load gallery videos. Use Choose video to select one."
        }
        if (galleryUris.isEmpty()) {
            status.text = "No videos found yet. Tap Choose video to select a clip."
        } else {
            status.text = "${galleryUris.size} recent videos • Tap a thumbnail to select"
        }
    }

    private fun makeVideoTile(uri: Uri, name: String, durationMs: Long): FrameLayout {
        val tile = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(35, 36, 40))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                selectedUri = uri
                status.text = "Selected: $name"
                Toast.makeText(this@MainActivity, "Video selected. Tap Prepare / Convert.", Toast.LENGTH_SHORT).show()
            }
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            try {
                val bitmap: Bitmap? = if (Build.VERSION.SDK_INT >= 29) {
                    contentResolver.loadThumbnail(uri, android.util.Size(dp(150), dp(150)), null)
                } else {
                    @Suppress("DEPRECATION")
                    ThumbnailUtils.createVideoThumbnail(uri.path ?: "", android.provider.MediaStore.Video.Thumbnails.MINI_KIND)
                }
                if (bitmap != null) setImageBitmap(bitmap)
            } catch (_: Exception) { }
        }
        tile.addView(image, FrameLayout.LayoutParams(-1, -1))
        tile.addView(TextView(this).apply {
            text = formatDuration(durationMs)
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(5), dp(3), dp(5), dp(3))
            background = rounded(Color.rgb(70, 70, 75), 8)
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(4), dp(4))
        })
        return tile
    }

    private fun formatDuration(ms: Long): String {
        val total = (ms / 1000).toInt()
        return String.format(java.util.Locale.US, "%d:%02d", total / 60, total % 60)
    }

    private fun buildConverterScreen() {
        val bg = Color.rgb(14, 15, 19)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(22))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { addView(page) }
        page.addView(makeButton("‹   Back to gallery", Color.rgb(36, 37, 44), Color.WHITE) { buildScreen() }, matchWrap())
        page.addView(TextView(this).apply {
            text = "Prepare video"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(18), 0, dp(4))
        }, matchWrap())
        page.addView(TextView(this).apply {
            text = "Convert for WhatsApp Status. Leave compression off for best clarity."
            textSize = 14f
            setTextColor(Color.LTGRAY)
        }, matchWrap())
        verticalOption = styledCheckBox("Vertical 9:16").apply { isChecked = false }
        splitOption = styledCheckBox("Split long videos into 60-second clips").apply { isChecked = true }
        compressOption = styledCheckBox("Smaller file (may reduce clarity)").apply { isChecked = false }
        saveGalleryOption = styledCheckBox("Save converted video to Gallery").apply { isChecked = true }
        val settings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(Color.rgb(29, 30, 36), 18)
        }
        listOf(verticalOption, splitOption, compressOption, saveGalleryOption).forEach { settings.addView(it, matchWrap()) }
        page.addView(settings, withTop(matchWrap(), 18))
        convertButton = makeButton("Convert video", Color.rgb(112, 65, 178), Color.WHITE) { beginConversion() }
        page.addView(convertButton, withTop(matchWrap(), 16))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = ProgressBar.GONE
        }
        page.addView(progress, withTop(matchWrap(), 12))
        status = TextView(this).apply {
            text = "Ready to convert."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(12), 0, dp(12))
        }
        page.addView(status, matchWrap())
        page.addView(makeButton("Add background music", Color.rgb(40, 41, 48), Color.WHITE) {
            if (!isConverting) musicPicker.launch(arrayOf("audio/*"))
        }, withTop(matchWrap(), 10))
        page.addView(makeButton("Share converted clips", Color.rgb(40, 41, 48), Color.WHITE) { shareOutputs() }, withTop(matchWrap(), 8))
        setContentView(scroll)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 201) {
            if (grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) refreshGallery()
            else status.text = "Gallery permission denied. Tap Choose video to select a video."
        }
    }

    private fun showAppMenu() {
        val choices = arrayOf("Prepare / Convert video", "Settings", "About / Contact", "Refresh gallery")
        android.app.AlertDialog.Builder(this)
            .setTitle("HD Status Menu")
            .setItems(choices) { _, which ->
                when (which) {
                    0 -> if (selectedUri == null) picker.launch("video/*") else buildConverterScreen()
                    1 -> android.app.AlertDialog.Builder(this).setTitle("Settings").setMessage("Leave compression off for best clarity. Gallery saving is enabled by default in the converter.").setPositiveButton("OK", null).show()
                    2 -> android.app.AlertDialog.Builder(this).setTitle("About HD Status").setMessage("Video converter for WhatsApp Status\\nDeveloper: Kalander\\nContact: +91-8050152388").setPositiveButton("OK", null).show()
                    3 -> refreshGallery()
                }
            }.show()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )


    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int? = null): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeColor != null) setStroke(dp(1), strokeColor)
        }

    private fun withTop(params: LinearLayout.LayoutParams, topDp: Int): LinearLayout.LayoutParams =
        params.apply { topMargin = dp(topDp) }

    private fun styledCheckBox(label: String) = CheckBox(this).apply {
        text = label
        textSize = 14f
        setTextColor(Color.WHITE)
        buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(80, 140, 255))
        setPadding(dp(4), dp(8), dp(4), dp(8))
    }

    private fun makeButton(label: String, backgroundColor: Int, textColor: Int, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            setTextColor(textColor)
            background = rounded(backgroundColor, 14)
            minHeight = dp(50)
            stateListAnimator = null
            setOnClickListener { action() }
        }

    private fun beginConversion() {
        val input = selectedUri
        if (input == null) {
            status.text = "Please choose a video first."
            return
        }
        if (isConverting) return

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, input)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            sourceWidth = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: 1280
            sourceHeight = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: 720
            // Estimate the source bitrate from metadata, then request a modest headroom.
            // This avoids needlessly starving a good source while avoiding extreme bitrate
            // requests that some Android hardware encoders silently clamp.
            val maxDimension = maxOf(sourceWidth, sourceHeight)
            val detectedBitrate = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
                ?.toIntOrNull()
                ?.takeIf { it > 0 }
            val resolutionCeiling = when {
                maxDimension >= 3000 -> 24_000_000
                maxDimension >= 1900 -> 16_000_000
                maxDimension >= 1200 -> 10_000_000
                maxDimension >= 700 -> 6_000_000
                else -> 3_500_000
            }
            val qualityFloor = when {
                maxDimension >= 3000 -> 12_000_000
                maxDimension >= 1900 -> 7_000_000
                maxDimension >= 1200 -> 3_500_000
                maxDimension >= 700 -> 2_000_000
                else -> 1_000_000
            }
            val resolutionDefault = when {
                maxDimension >= 3000 -> 16_000_000
                maxDimension >= 1900 -> 9_000_000
                maxDimension >= 1200 -> 5_000_000
                maxDimension >= 700 -> 3_000_000
                else -> 1_800_000
            }
            sourceBitrate = if (detectedBitrate != null) {
                (detectedBitrate * 1.20).toInt().coerceIn(qualityFloor, resolutionCeiling)
            } else {
                resolutionDefault.coerceIn(qualityFloor, resolutionCeiling)
            }
        } catch (_: Exception) {
            durationMs = 0L
        } finally {
            try { retriever.release() } catch (_: Exception) { }
        }
        if (durationMs <= 0L) {
            status.text = "Could not read this video's duration. Try another video."
            return
        }

        val outputDir = File(filesDir, "converted")
        if (!outputDir.exists() && !outputDir.mkdirs()) {
            status.text = "Could not create output folder."
            return
        }
        outputFiles.clear()
        segments.clear()
        useVertical = verticalOption.isChecked
        requestedBitrate = if (compressOption.isChecked) (sourceBitrate * 0.60).toInt().coerceAtLeast(900_000) else sourceBitrate
        val segmentLength = 60_000L
        if (splitOption.isChecked && durationMs > segmentLength) {
            var start = 0L
            while (start < durationMs) {
                val end = minOf(start + segmentLength, durationMs)
                segments.add(start to end)
                start = end
            }
        } else {
            segments.add(0L to durationMs)
        }
        currentSegment = 0
        isConverting = true
        convertButton.isEnabled = false
        progress.visibility = ProgressBar.VISIBLE
        progress.progress = 0
        exportNext(input, outputDir)
    }

    private fun exportNext(input: Uri, outputDir: File) {
        if (currentSegment >= segments.size) {
            isConverting = false
            convertButton.isEnabled = true
            progress.progress = 100
            progress.visibility = ProgressBar.GONE
            if (saveGalleryOption.isChecked) {
                saveOutputsToGallery()
            } else {
                status.text = "Export complete: ${outputFiles.size} clip(s). Files remain inside HD Status. Requested video bitrate: ${requestedBitrate / 1_000_000.0} Mbps."
            }
            return
        }

        val (startMs, endMs) = segments[currentSegment]
        val file = File(outputDir, "HDStatus_${System.currentTimeMillis()}_${currentSegment + 1}.mp4")
        val mediaItem = MediaItem.Builder()
            .setUri(input)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
            )
            .build()
        val videoEffects = if (useVertical) {
            listOf(Presentation.createForAspectRatio(9f / 16f, Presentation.LAYOUT_SCALE_TO_FIT))
        } else {
            emptyList()
        }
        val editedItem = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                outputFiles.add(file)
                currentSegment++
                progress.progress = (currentSegment * 100) / segments.size
                status.text = "Converted clip $currentSegment of ${segments.size}…"
                exportNext(input, outputDir)
            }

            override fun onError(
                composition: androidx.media3.transformer.Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                transformer = null
                isConverting = false
                convertButton.isEnabled = true
                file.delete()
                progress.visibility = ProgressBar.GONE
                status.text = "Conversion failed on clip ${currentSegment + 1}. Try a different video."
                Toast.makeText(this@MainActivity, exportException.errorCodeName, Toast.LENGTH_LONG).show()
            }
        }
        try {
            status.text = "Converting clip ${currentSegment + 1} of ${segments.size}…"
            val encoderFactory = DefaultEncoderFactory.Builder(this)
                .setRequestedVideoEncoderSettings(
                    VideoEncoderSettings.Builder()
                        .setBitrate(requestedBitrate)
                        .build()
                )
                .build()
            transformer = Transformer.Builder(this)
                .setEncoderFactory(encoderFactory)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(listener)
                .build()
            transformer?.start(editedItem, file.absolutePath)
        } catch (e: Exception) {
            transformer = null
            isConverting = false
            convertButton.isEnabled = true
            file.delete()
            status.text = "Could not start conversion. Try another video."
        }
    }


    private fun saveOutputsToGallery() {
        val files = outputFiles.filter { it.exists() }
        if (files.isEmpty()) {
            status.text = "Conversion finished, but no output files were found."
            return
        }
        var saved = 0
        var failed = 0
        for (file in files) {
            var insertedUri: Uri? = null
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HD Status")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }
                insertedUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Gallery could not create a media entry")
                contentResolver.openOutputStream(insertedUri, "w").use { output ->
                    if (output == null) throw IllegalStateException("Could not open Gallery destination")
                    file.inputStream().use { input -> input.copyTo(output) }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    contentResolver.update(insertedUri, done, null, null)
                }
                saved++
            } catch (_: Exception) {
                failed++
                if (insertedUri != null) {
                    try { contentResolver.delete(insertedUri, null, null) } catch (_: Exception) { }
                }
            }
        }
        status.text = when {
            saved == files.size -> "Conversion complete. Saved $saved video(s) to Gallery → Movies/HD Status."
            saved > 0 -> "Saved $saved of ${files.size} video(s) to Gallery. Some could not be saved."
            else -> "Conversion complete, but Gallery save failed. Use Share Converted Clips to access your videos."
        }
        if (failed > 0) Toast.makeText(this, "Gallery save failed for $failed file(s).", Toast.LENGTH_LONG).show()
    }

    private fun shareOutputs() {
        val files = outputFiles.filter { it.exists() }
        if (files.isEmpty()) {
            status.text = "Convert a video first."
            return
        }
        try {
            val uris = ArrayList(files.map {
                FileProvider.getUriForFile(this, "$packageName.fileprovider", it)
            })
            val intent = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, uris[0])
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "video/mp4"
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                }
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "Share to WhatsApp or another app"))
        } catch (_: Exception) {
            status.text = "Could not open the share menu."
        }
    }

    override fun onDestroy() {
        if (isConverting) {
            transformer?.cancel()
            transformer = null
        }
        super.onDestroy()
    }
}
