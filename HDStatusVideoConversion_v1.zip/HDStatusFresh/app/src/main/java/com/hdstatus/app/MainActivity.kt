package com.hdstatus.app

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.media.MediaMetadataRetriever
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.widget.CheckBox
import android.widget.ProgressBar
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.Composition

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 13, 17)
    private val tileBg = Color.rgb(32, 33, 40)
    private val blue = Color.rgb(43, 111, 245)
    private val purple = Color.rgb(132, 70, 183)
    private val muted = Color.rgb(170, 175, 187)
    private lateinit var grid: GridLayout
    private lateinit var status: TextView
    private var selectedVideo: Uri? = null
    private var selectedName = ""
    private lateinit var splitCheck: CheckBox
    private lateinit var saveCheck: CheckBox
    private lateinit var compressCheck: CheckBox
    private lateinit var convertStatus: TextView
    private lateinit var convertButton: Button
    private var isConverting = false
    private var segmentStarts = mutableListOf<Pair<Long, Long>>()
    private var segmentIndex = 0
    private var tempOutputs = mutableListOf<File>()
    private var savedOutputs = mutableListOf<Uri>()
    private var totalDurationMs = 0L

    private val pickVideo = registerForActivityResultCompat()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showGallery()
    }

    // Uses a platform activity result contract without adding an AndroidX dependency.
    private fun registerForActivityResultCompat(): (Intent) -> Unit = { intent ->
        @Suppress("DEPRECATION")
        startActivityForResult(intent, 1001)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            selectedVideo = uri
            selectedName = queryName(uri) ?: "Selected video"
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            showPrepareScreen()
        }
    }

    private fun showGallery() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(17, 18, 22))
        }
        header.addView(TextView(this).apply {
            text = "HD Status"
            textSize = 34f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }, LinearLayout.LayoutParams(0, dp(52), 1f))
        header.addView(TextView(this).apply {
            text = "☰"
            textSize = 29f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setOnClickListener { showMenu() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(header)

        status = TextView(this).apply {
            text = "RECENT VIDEOS"
            textSize = 11f
            letterSpacing = .14f
            setTextColor(muted)
            setPadding(dp(12), dp(14), dp(12), dp(8))
        }
        root.addView(status)
        val scroller = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), 0, dp(2), dp(12))
        }
        grid = GridLayout(this).apply { columnCount = 4; useDefaultMargins = false }
        content.addView(grid, LinearLayout.LayoutParams(-1, -2))
        val choose = button("Choose video", blue, Color.WHITE) { launchPicker() }
        content.addView(choose, LinearLayout.LayoutParams(-1, dp(52)).apply {
            setMargins(dp(8), dp(12), dp(8), dp(8))
        })
        content.addView(button("Prepare selected video", purple, Color.WHITE) {
            if (selectedVideo == null) launchPicker() else showPrepareScreen()
        }, LinearLayout.LayoutParams(-1, dp(52)).apply {
            setMargins(dp(8), dp(4), dp(8), dp(8))
        })
        scroller.addView(content)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(8), dp(6), dp(8))
            background = round(Color.rgb(27, 28, 34), 25, Color.rgb(58, 60, 68))
        }
        listOf("▣\nVideo", "▧\nPhoto", "▤\nAlbums", "✦\nAI").forEachIndexed { i, label ->
            nav.addView(TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 12f
                setTextColor(if (i == 0) Color.rgb(110, 155, 255) else muted)
                setOnClickListener {
                    if (i == 0) loadGallery()
                    else Toast.makeText(this@MainActivity, "$label tools are not available in this first version.", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(0, dp(42), 1f))
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(dp(10), dp(8), dp(10), dp(10))
        })
        setContentView(root)
        loadGallery()
    }

    private fun loadGallery() {
        if (!::grid.isInitialized) return
        grid.removeAllViews()
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(permission), 200)
            status.text = "Allow video access to show your gallery"
            return
        }
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION)
        var count = 0
        try {
            contentResolver.query(collection, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durationCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                while (c.moveToNext() && count < 120) {
                    val id = c.getLong(idCol)
                    val name = c.getString(nameCol) ?: "Video"
                    val duration = c.getLong(durationCol)
                    val uri = ContentUris.withAppendedId(collection, id)
                    grid.addView(videoTile(uri, name, duration), GridLayout.LayoutParams().apply {
                        width = 0
                        height = dp(112)
                        columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                        setMargins(dp(1), dp(1), dp(1), dp(1))
                    })
                    count++
                }
            }
        } catch (_: Exception) {
            status.text = "Could not read videos. Use Choose video instead."
        }
        if (count == 0) status.text = "No videos found • Tap Choose video"
        else status.text = "$count recent videos • Tap a thumbnail to select"
    }

    private fun videoTile(uri: Uri, name: String, durationMs: Long): FrameLayout {
        val frame = FrameLayout(this).apply {
            setBackgroundColor(tileBg)
            setOnClickListener {
                selectedVideo = uri
                selectedName = name
                Toast.makeText(this@MainActivity, "Selected: $name", Toast.LENGTH_SHORT).show()
                showPrepareScreen()
            }
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            try {
                val bitmap: Bitmap? = if (Build.VERSION.SDK_INT >= 29) {
                    contentResolver.loadThumbnail(uri, android.util.Size(dp(160), dp(160)), null)
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Video.Thumbnails.getThumbnail(contentResolver, ContentUris.parseId(uri), MediaStore.Video.Thumbnails.MINI_KIND, null)
                }
                if (bitmap != null) setImageBitmap(bitmap)
            } catch (_: Exception) {}
        }
        frame.addView(image, FrameLayout.LayoutParams(-1, -1))
        frame.addView(TextView(this).apply {
            text = durationText(durationMs)
            textSize = 10f
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(3), dp(4), dp(3))
            background = round(Color.rgb(70, 70, 75), 7)
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(4), dp(4))
        })
        return frame
    }

    private fun showPrepareScreen() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(24))
            setBackgroundColor(bg)
        }
        root.addView(button("‹  Back to gallery", tileBg, Color.WHITE) { if (!isConverting) showGallery() })
        root.addView(TextView(this).apply {
            text = "Prepare video"
            textSize = 29f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(0, dp(20), 0, dp(6))
        })
        root.addView(TextView(this).apply {
            text = selectedName.ifBlank { "No video selected" }
            textSize = 14f
            setTextColor(muted)
        })
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = round(tileBg, 18, Color.rgb(58, 60, 68))
        }
        splitCheck = checkOption("Split long videos into 60-second clips", true)
        saveCheck = checkOption("Save converted videos to Gallery", true)
        compressCheck = checkOption("Smaller file (may reduce clarity)", false)
        card.addView(splitCheck)
        card.addView(saveCheck)
        card.addView(compressCheck)
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })
        convertButton = button("Convert video", blue, Color.WHITE) { startConversion() }
        root.addView(convertButton, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(16) })
        convertStatus = TextView(this).apply {
            text = "Ready. High-quality conversion is selected by default."
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(14), 0, dp(8))
        }
        root.addView(convertStatus)
        root.addView(button("Share converted clips", purple, Color.WHITE) { shareConverted() },
            LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) })
        root.addView(TextView(this).apply {
            text = "Conversion re-encodes video, so a small quality change is possible. Leave Smaller file off for the best available quality. Split points may be approximate."
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(16), 0, 0)
        })
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun checkOption(label: String, checked: Boolean) = CheckBox(this).apply {
        text = label
        isChecked = checked
        textSize = 14f
        setTextColor(Color.WHITE)
        buttonTintList = android.content.res.ColorStateList.valueOf(blue)
        setPadding(dp(2), dp(8), dp(2), dp(8))
    }

    private fun startConversion() {
        val uri = selectedVideo
        if (uri == null) {
            Toast.makeText(this, "Choose a video first.", Toast.LENGTH_SHORT).show()
            return
        }
        if (isConverting) return
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            totalDurationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            convertStatus.text = "Cannot read this video: ${e.message ?: "unknown error"}"
            return
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
        if (totalDurationMs <= 0L) {
            convertStatus.text = "Could not detect video duration."
            return
        }
        segmentStarts.clear()
        tempOutputs.clear()
        savedOutputs.clear()
        val split = splitCheck.isChecked
        val chunkMs = if (split) 60_000L else totalDurationMs
        var start = 0L
        while (start < totalDurationMs) {
            val end = minOf(start + chunkMs, totalDurationMs)
            segmentStarts.add(start to end)
            start = end
        }
        segmentIndex = 0
        isConverting = true
        convertButton.isEnabled = false
        splitCheck.isEnabled = false
        saveCheck.isEnabled = false
        compressCheck.isEnabled = false
        convertStatus.text = "Starting conversion…"
        convertNextSegment()
    }

    private fun convertNextSegment() {
        if (segmentIndex >= segmentStarts.size) {
            isConverting = false
            convertButton.isEnabled = true
            splitCheck.isEnabled = true
            saveCheck.isEnabled = true
            compressCheck.isEnabled = true
            convertStatus.text = "Conversion complete: ${tempOutputs.size} clip(s)." +
                if (saveCheck.isChecked) " Saved to Movies/HD Status." else " Saved temporarily in app storage."
            Toast.makeText(this, "Conversion complete", Toast.LENGTH_LONG).show()
            return
        }
        val uri = selectedVideo ?: return
        val (startMs, endMs) = segmentStarts[segmentIndex]
        val output = File(cacheDir, "hdstatus_${System.currentTimeMillis()}_${segmentIndex + 1}.mp4")
        tempOutputs.add(output)
        val mediaItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
            )
            .build()
        val editedItem = EditedMediaItem.Builder(mediaItem).build()
        val builder = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
        val transformer = builder.addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                try {
                    if (saveCheck.isChecked) {
                        val saved = saveToGallery(output, segmentIndex + 1)
                        savedOutputs.add(saved)
                    }
                    segmentIndex++
                    convertStatus.text = "Converted ${segmentIndex}/${segmentStarts.size} clip(s)…"
                    convertNextSegment()
                } catch (e: Exception) {
                    failConversion("Could not save output: ${e.message ?: "unknown error"}")
                }
            }

            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                failConversion("Conversion failed: ${exportException.message ?: "unsupported video"}")
            }
        }).build()
        try {
            convertStatus.text = "Converting clip ${segmentIndex + 1}/${segmentStarts.size}…"
            transformer.start(editedItem, output.absolutePath)
        } catch (e: Exception) {
            failConversion("Could not start conversion: ${e.message ?: "unknown error"}")
        }
    }

    private fun failConversion(message: String) {
        isConverting = false
        convertButton.isEnabled = true
        splitCheck.isEnabled = true
        saveCheck.isEnabled = true
        compressCheck.isEnabled = true
        convertStatus.text = message
    }

    private fun saveToGallery(file: File, index: Int): Uri {
        val name = "HDStatus_${System.currentTimeMillis()}_$index.mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/HD Status")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Gallery refused to create a file")
            try {
                contentResolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(file).use { input -> input.copyTo(out) }
                } ?: throw IllegalStateException("Could not open Gallery output")
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
                return uri
            } catch (e: Exception) {
                contentResolver.delete(uri, null, null)
                throw e
            }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "HD Status")
            if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Cannot create Movies/HD Status")
            val target = File(dir, name)
            FileInputStream(file).use { input -> FileOutputStream(target).use { out -> input.copyTo(out) } }
            android.media.MediaScannerConnection.scanFile(this, arrayOf(target.absolutePath), arrayOf("video/mp4"), null)
            return Uri.fromFile(target)
        }
    }

    private fun shareConverted() {
        if (savedOutputs.isEmpty()) {
            Toast.makeText(this, "Convert a video with Save to Gallery enabled first.", Toast.LENGTH_LONG).show()
            return
        }
        val uris = ArrayList(savedOutputs)
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uris[0])
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "video/mp4"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        startActivity(Intent.createChooser(intent, "Share converted clips"))
    }

    private fun launchPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, 1001)
    }

    private fun showMenu() {
        AlertDialog.Builder(this)
            .setTitle("HD Status")
            .setItems(arrayOf("Refresh video gallery", "Choose video", "About")) { _, which ->
                when (which) {
                    0 -> loadGallery()
                    1 -> launchPicker()
                    2 -> AlertDialog.Builder(this).setTitle("About HD Status").setMessage("A fresh start for HD Status. Video gallery and sharing are available in this version.").setPositiveButton("OK", null).show()
                }
            }.show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 200) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) loadGallery()
            else status.text = "Permission denied. Use Choose video to select a clip."
        }
    }

    private fun button(label: String, color: Int, textColor: Int, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(textColor)
            background = round(color, 14)
            minHeight = dp(48)
            stateListAnimator = null
            setOnClickListener { action() }
        }

    private fun round(color: Int, radiusDp: Int, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun durationText(ms: Long): String {
        val total = (ms / 1000).toInt()
        return String.format(Locale.US, "%d:%02d", total / 60, total % 60)
    }

    private fun queryName(uri: Uri): String? {
        return contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
