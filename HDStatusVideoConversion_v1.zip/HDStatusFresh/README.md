# HD Status — Fresh Video Converter Build

Included:
- Dark four-column video gallery with thumbnails and durations
- Video selection and Android document picker
- Media3 Transformer H.264/AAC video conversion
- Optional 60-second clipped exports
- Optional saving to Movies/HD Status in Gallery
- Share saved converted clips through Android share sheet
- High-quality conversion is default; smaller-file option is exposed but Android encoder defaults may vary

Known limitations:
- Transformer re-encodes video and may alter visual quality; this is not lossless splitting.
- Music mixing, trim/text/sticker editing, 9:16 crop controls, Photo/Albums/AI screens are not implemented.
- Build using Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, SDK 35.
