# HD Status Android Project

- App name: HD Status
- Developer: Kalander
- Package: `com.hdstatus.app`
- Contact: +91-8050152388
- Language: Kotlin
- APK: built by GitHub Actions

## Included in this source build

- Select a video from Android's file picker.
- Export MP4 with H.264 video and AAC audio using Android Media3 Transformer.
- Optional 9:16 presentation mode. It is off by default to avoid unnecessary scaling.
- Optional automatic splitting into 60-second clips.
- Share exported clips using Android's share sheet, including WhatsApp when installed.
- No watermark is added by this app.
- Contact details in About screen.

## Important scope note

This is a working starter version, not yet a complete feature-for-feature PureStatus replica. A full photo enhancement pipeline, timeline editor, text/sticker overlays, music mixing, and a dedicated quality/compression selector still require implementation and device testing. MP4 re-encoding can change quality; no app can restore detail absent from the source.

## Build on GitHub using only your phone

1. Open `https://github.com/new` in Chrome and create a **public or private** repository named `HDStatus-Android`. Leave **Add a README** unchecked.
2. Download and extract this ZIP on your phone if your browser/file manager supports it.
3. Open the new repository in Chrome. Choose **Add file → Upload files**. Upload the *contents* of the extracted `HDStatusFresh` folder, not the ZIP itself. Keep the `.github` folder and its `workflows` subfolder. If GitHub mobile hides upload options, use Chrome's **Desktop site**.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab and select **Build HD Status APK**. Wait for the run to finish with a green check.
6. Open that successful run, scroll to **Artifacts**, and download `HD-Status-debug-apk`.
7. Extract the artifact ZIP and tap `app-debug.apk`. If Android prompts, allow Chrome or your file manager to install unknown apps, then install.

## Build details

The workflow builds `app/build/outputs/apk/debug/app-debug.apk` and uploads it as an artifact. Debug APKs are for testing; publishing to Play Store requires a properly signed release build.


## Music option status
This update adds a local audio-file picker and shortcuts to Pixabay Music, YouTube Audio Library, and Mixkit. **Important:** selecting music does not yet mix it into the exported video. Audio mixing and volume controls still require a later implementation and build/test cycle. Use tracks only when their license permits your intended use.


## Quality-oriented export update
This version requests a video bitrate based on the source dimensions and does not add a 720p resize when vertical mode is disabled. Media3/device encoders may adjust the requested bitrate. This reduces avoidable re-encoding loss where possible; it does not perform AI sharpening or restore detail missing from the source. Any re-encoding can still cause some quality loss.


## HD encoder update
- Requests H.264/AAC output with a bitrate selected from source dimensions. The device encoder may not honor the exact requested bitrate.
- Keeps source dimensions when 9:16 mode is off. Enabling 9:16 changes the presentation and can add bars; it does not magically improve detail.
- Splits long videos into 60-second segments. Since Media3 re-encodes clips, this is not guaranteed lossless stream-copy splitting.
- Optional smaller-file mode requests a lower bitrate and may reduce detail.
- Audio picker and free-music website shortcuts are present, but **mixing the selected music into the export is not implemented in this build**.
- This is not AI upscaling or deblurring. A higher bitrate cannot recover details missing from a blurry source. Test on actual devices and compare WhatsApp uploads.


## PureStatus comparison-based profile (experimental)
The provided sample comparison showed a 720x1280 H.264 source around 2.43 Mbps and a 768x1280 export around 2.54 Mbps. This build uses the detected source bitrate plus approximately 5%, bounded by resolution-based limits, when Android exposes source bitrate metadata. It does **not** force the unusual 768x1280 dimensions; it preserves the original frame dimensions unless 9:16 mode is enabled. The APK analysis has not established PureStatus's exact command or encoder settings, so this is an evidence-informed approximation, not an exact reproduction. Android hardware encoders may ignore or adjust requested bitrates.


## PureStatus-inspired matching build (v1.1)
This build uses an evidence-informed approximation based on the supplied sample videos and strings found in the PureStatus APK. It uses H.264/AAC via Android Media3 and requests source-aware bitrates. It preserves source dimensions unless optional 9:16 mode is enabled and keeps 60-second clips.

This is **not an exact clone**: the exact PureStatus method-to-command mapping has not been fully recovered, and the current project does not implement FFmpeg CRF profiles, real music mixing, photo enhancement, text/sticker editing, or a complete video timeline. The music picker is only a picker. Android hardware encoders may adjust requested bitrate, and re-encoding can reduce detail. Build and compare the same original video in both apps before judging quality.


## Clarity-loss fix (conversion/compression)

The conversion path now reads the source video's bitrate metadata and requests about 20% headroom, bounded by resolution-based limits. It keeps the original frame size unless 9:16 is explicitly enabled. The optional Compress checkbox intentionally lowers the requested bitrate by 40%; leave it unchecked for the clearest output. Android hardware encoders can clamp requested settings, and H.264 re-encoding is always lossy, so this reduces avoidable quality loss but cannot restore detail already absent in the source. If exact source quality is required, use a no-re-encode remux/split path rather than Convert.


## Save converted videos to Gallery

The conversion screen includes a checked-by-default “Save converted video to Gallery” option. On successful conversion, MP4 clips are copied into Android MediaStore under `Movies/HD Status` so they appear in Gallery/Photos apps. On Android 10 and later this uses scoped storage and does not need broad storage permission. If the option is unchecked, outputs remain in the app's private converted folder and can still be shared using the Share button.


## PureStatus-inspired interface refresh

Dark video-studio theme with a large brand header and menu, selected-video panel, export settings, primary conversion action, quick tool tiles, and bottom navigation inspired by the user's screenshots. This version does not copy PureStatus branding or assets. Photo, Albums, and AI tabs are visual placeholders and report that those features are not yet implemented; the working conversion features remain available.
