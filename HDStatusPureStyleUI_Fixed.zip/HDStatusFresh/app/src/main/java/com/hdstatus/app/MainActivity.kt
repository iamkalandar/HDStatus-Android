package com.hdstatus.app

import android.content.ContentValues
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var verticalOption: CheckBox
    private lateinit var splitOption: CheckBox
    private lateinit var compressOption: CheckBox
    private lateinit var saveGalleryOption: CheckBox
    private lateinit var convertButton: Button
    private var selectedUri: Uri? = null
    private var selectedMusicUri: Uri? = null
    private var transformer: Transformer? = null
    private var isConverting = false
    private val outputFiles = mutableListOf<File>()
    private var segments = mutableListOf<Pair<Long, Long>>()
    private var currentSegment = 0
    private var durationMs = 0L
    private var sourceWidth = 1280
    private var sourceHeight = 720
    private var sourceBitrate = 8_000_000
    private var requestedBitrate = 8_000_000
    private var useVertical = false

    private val musicPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            selectedMusicUri = uri
            status.text = "Audio file selected. This build does not yet mix it into the exported video."
        }
    }

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            outputFiles.clear()
            status.text = "Video selected. Quality mode requests a bitrate based on source metadata and keeps the original frame size unless 9:16 is enabled. Re-encoding can still lose detail."
        } else {
            status.text = "No video selected."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val bg = Color.rgb(13, 14, 18)
        val panel = Color.rgb(29, 30, 37)
        val accent = Color.rgb(52, 112, 245)
        val purple = Color.rgb(137, 77, 190)
        val white = Color.WHITE
        val muted = Color.rgb(174, 179, 191)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            addView(page)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(10), dp(8), dp(16))
        }
        val brand = TextView(this).apply {
            text = "HD Status"
            textSize = 31f
            setTextColor(white)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val menuButton = TextView(this).apply {
            text = "☰"
            textSize = 32f
            gravity = Gravity.CENTER
            setTextColor(white)
            setOnClickListener { showAppMenu() }
        }
        header.addView(brand)
        header.addView(menuButton, LinearLayout.LayoutParams(dp(52), dp(48)))
        page.addView(header, matchWrap())

        val galleryLabel = TextView(this).apply {
            text = if (selectedUri == null) "Your videos" else "Selected video"
            textSize = 13f
            setTextColor(muted)
            setPadding(dp(8), dp(4), dp(8), dp(10))
        }
        page.addView(galleryLabel, matchWrap())

        val previewCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(28), dp(20), dp(24))
            background = rounded(panel, 22, Color.rgb(54, 56, 66))
        }
        val videoGlyph = TextView(this).apply {
            text = if (selectedUri == null) "▶" else "▣"
            textSize = 46f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(125, 164, 255))
        }
        val previewTitle = TextView(this).apply {
            text = if (selectedUri == null) "Choose a video to get started" else "Video selected and ready"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(white)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(0, dp(8), 0, dp(6))
        }
        val previewSub = TextView(this).apply {
            text = "HD export  •  60-second clips  •  No watermark"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(muted)
        }
        previewCard.addView(videoGlyph, matchWrap())
        previewCard.addView(previewTitle, matchWrap())
        previewCard.addView(previewSub, matchWrap())
        page.addView(previewCard, withTop(matchWrap(), 4))

        val chooseButton = makeButton("Choose video", accent, white) {
            if (!isConverting) picker.launch("video/*")
        }
        page.addView(chooseButton, withTop(matchWrap(), 14))

        val settingsTitle = sectionLabel("EXPORT OPTIONS", muted)
        page.addView(settingsTitle, withTop(matchWrap(), 20))
        verticalOption = styledCheckBox("Vertical 9:16").apply { isChecked = false }
        splitOption = styledCheckBox("Split long videos into 60-second clips").apply { isChecked = true }
        compressOption = styledCheckBox("Smaller file (may reduce clarity)")
        saveGalleryOption = styledCheckBox("Save converted video to Gallery").apply { isChecked = true }

        val settings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = rounded(panel, 18, Color.rgb(54, 56, 66))
        }
        listOf(verticalOption, splitOption, compressOption, saveGalleryOption).forEachIndexed { index, v ->
            settings.addView(v, matchWrap())
            if (index < 3) {
                settings.addView(android.view.View(this).apply { setBackgroundColor(Color.rgb(53, 55, 64)) },
                    LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
        page.addView(settings, withTop(matchWrap(), 8))

        convertButton = makeButton("Convert in HD", purple, white) { beginConversion() }
        page.addView(convertButton, withTop(matchWrap(), 14))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = ProgressBar.GONE
            progressTintList = ColorStateList.valueOf(accent)
        }
        page.addView(progress, withTop(matchWrap(), 10))
        status = TextView(this).apply {
            text = "Ready when you are."
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(12), dp(10), dp(12))
        }
        page.addView(status, matchWrap())

        page.addView(sectionLabel("QUICK TOOLS", muted), withTop(matchWrap(), 10))
        val toolsGrid = android.widget.GridLayout(this).apply {
            columnCount = 2
            rowCount = 2
        }
        val music = makeToolTile("♫", "Background music", panel) {
            if (!isConverting) musicPicker.launch(arrayOf("audio/*"))
        }
        val freeMusic = makeToolTile("✧", "Free music library", panel) {
            android.app.AlertDialog.Builder(this@MainActivity)
                .setTitle("Free music for videos")
                .setItems(arrayOf("Pixabay Music", "YouTube Audio Library", "Mixkit Music")) { _, which ->
                    val url = when (which) { 0 -> "https://pixabay.com/music/"; 1 -> "https://www.youtube.com/audiolibrary"; else -> "https://mixkit.co/free-stock-music/" }
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }.show()
        }
        val share = makeToolTile("↗", "Share exports", panel) { shareOutputs() }
        val about = makeToolTile("ⓘ", "About & support", panel) { showAbout() }
        listOf(music, freeMusic, share, about).forEach { tile ->
            val lp = android.widget.GridLayout.LayoutParams().apply {
                width = 0
                height = dp(104)
                columnSpec = android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            toolsGrid.addView(tile, lp)
        }
        page.addView(toolsGrid, withTop(matchWrap(), 8))

        val bottomNav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(Color.rgb(25, 26, 32), 28, Color.rgb(64, 65, 75))
        }
        listOf("▣\\nVideo", "▧\\nPhoto", "▤\\nAlbums", "✦\\nAI").forEachIndexed { index, label ->
            val item = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(if (index == 0) Color.rgb(135, 170, 255) else muted)
                setPadding(dp(4), dp(6), dp(4), dp(6))
                setOnClickListener {
                    if (index == 0) picker.launch("video/*")
                    else Toast.makeText(this@MainActivity, when(index) { 1 -> "Photo tools are coming soon."; 2 -> "Albums are not available in this build yet."; else -> "AI tools are not available in this build yet." }, Toast.LENGTH_SHORT).show()
                }
            }
            bottomNav.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        page.addView(bottomNav, withTop(matchWrap(), 18))
        setContentView(scroll)
    }

    private fun styledCheckBox(label: String) = CheckBox(this).apply {
        text = label
        textSize = 14f
        setTextColor(Color.WHITE)
        buttonTintList = ColorStateList.valueOf(Color.rgb(95, 145, 255))
        setPadding(dp(4), dp(8), dp(4), dp(8))
    }

    private fun makeToolTile(symbol: String, label: String, color: Int, action: () -> Unit) =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(color, 18, Color.rgb(54, 56, 66))
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
            addView(TextView(this@MainActivity).apply {
                text = symbol
                textSize = 28f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(140, 175, 255))
            }, matchWrap())
            addView(TextView(this@MainActivity).apply {
                text = label
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setPadding(0, dp(4), 0, 0)
            }, matchWrap())
        }

    private fun showAppMenu() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(8))
        }
        val heading = TextView(this).apply {
            text = "⚙  Menu"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(14))
        }
        panel.addView(heading, matchWrap())
        val options = listOf(
            "🌐   Language: English" to { Toast.makeText(this, "English is the current language.", Toast.LENGTH_SHORT).show() },
            "⚙   Settings" to { showSettingsDialog() },
            "➤   Share HD Status" to { shareApp() },
            "♡   Write feedback" to { showFeedbackDialog() },
            "🐞   Bug report" to { showFeedbackDialog() },
            "ⓘ   About / Contact" to { showAbout() },
            "🔒   Privacy information" to { android.app.AlertDialog.Builder(this).setTitle("Privacy").setMessage("Your selected videos are processed on this device. Exports are saved only when you enable Gallery saving.").setPositiveButton("OK", null).show() }
        )
        options.forEach { (label, action) ->
            val button = makeButton(label, Color.rgb(55, 56, 66), Color.WHITE, action)
            panel.addView(button, withTop(matchWrap(), 6))
        }
        android.app.AlertDialog.Builder(this)
            .setView(panel)
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showSettingsDialog() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Export settings")
            .setMessage("For best clarity, leave compression off. Vertical 9:16 reframes the video. Gallery saving is enabled by default.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showFeedbackDialog() {
        val edit = android.widget.EditText(this).apply { hint = "Describe your feedback or issue" }
        android.app.AlertDialog.Builder(this)
            .setTitle("Feedback / Bug report")
            .setView(edit)
            .setPositiveButton("Continue") { _, _ ->
                val body = Uri.encode(edit.text.toString())
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
                intent.putExtra(Intent.EXTRA_SUBJECT, "HD Status feedback")
                intent.putExtra(Intent.EXTRA_TEXT, body)
                try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "No email app found.", Toast.LENGTH_SHORT).show() }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun shareApp() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Try HD Status — prepare videos for WhatsApp Status.")
        }
        startActivity(Intent.createChooser(send, "Share HD Status"))
    }

    private fun showAbout() {
        android.app.AlertDialog.Builder(this)
            .setTitle("About HD Status")
            .setMessage("HD Status\\nVideo converter for WhatsApp Status\\n\\nDeveloper: Kalander\\nContact: +91-8050152388\\n\\nVideo conversion runs on your phone. Supported formats depend on device codecs.")
            .setPositiveButton("OK", null)
            .setNeutralButton("WhatsApp contact") { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/918050152388")))
            }
            .show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeColor != null) setStroke(dp(1), strokeColor)
        }

    private fun withTop(params: LinearLayout.LayoutParams, topDp: Int): LinearLayout.LayoutParams =
        params.apply { topMargin = dp(topDp) }

    private fun sectionLabel(label: String, color: Int) = TextView(this).apply {
        text = label
        textSize = 11f
        setTextColor(color)
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        letterSpacing = 0.12f
    }

    private fun makeButton(label: String, backgroundColor: Int, textColor: Int, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setTextColor(textColor)
            background = rounded(backgroundColor, 14)
            minHeight = dp(52)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            stateListAnimator = null
            setOnClickListener { action() }
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun beginConversion() {
        val input = selectedUri
        if (input == null) {
            status.text = "Please choose a video first."
            return
        }
        if (isConverting) return

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, input)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            sourceWidth = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: 1280
            sourceHeight = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: 720
            // Estimate the source bitrate from metadata, then request a modest headroom.
            // This avoids needlessly starving a good source while avoiding extreme bitrate
            // requests that some Android hardware encoders silently clamp.
            val maxDimension = maxOf(sourceWidth, sourceHeight)
            val detectedBitrate = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
                ?.toIntOrNull()
                ?.takeIf { it > 0 }
            val resolutionCeiling = when {
                maxDimension >= 3000 -> 24_000_000
                maxDimension >= 1900 -> 16_000_000
                maxDimension >= 1200 -> 10_000_000
                maxDimension >= 700 -> 6_000_000
                else -> 3_500_000
            }
            val qualityFloor = when {
                maxDimension >= 3000 -> 12_000_000
                maxDimension >= 1900 -> 7_000_000
                maxDimension >= 1200 -> 3_500_000
                maxDimension >= 700 -> 2_000_000
                else -> 1_000_000
            }
            val resolutionDefault = when {
                maxDimension >= 3000 -> 16_000_000
                maxDimension >= 1900 -> 9_000_000
                maxDimension >= 1200 -> 5_000_000
                maxDimension >= 700 -> 3_000_000
                else -> 1_800_000
            }
            sourceBitrate = if (detectedBitrate != null) {
                (detectedBitrate * 1.20).toInt().coerceIn(qualityFloor, resolutionCeiling)
            } else {
                resolutionDefault.coerceIn(qualityFloor, resolutionCeiling)
            }
        } catch (_: Exception) {
            durationMs = 0L
        } finally {
            try { retriever.release() } catch (_: Exception) { }
        }
        if (durationMs <= 0L) {
            status.text = "Could not read this video's duration. Try another video."
            return
        }

        val outputDir = File(filesDir, "converted")
        if (!outputDir.exists() && !outputDir.mkdirs()) {
            status.text = "Could not create output folder."
            return
        }
        outputFiles.clear()
        segments.clear()
        useVertical = verticalOption.isChecked
        requestedBitrate = if (compressOption.isChecked) (sourceBitrate * 0.60).toInt().coerceAtLeast(900_000) else sourceBitrate
        val segmentLength = 60_000L
        if (splitOption.isChecked && durationMs > segmentLength) {
            var start = 0L
            while (start < durationMs) {
                val end = minOf(start + segmentLength, durationMs)
                segments.add(start to end)
                start = end
            }
        } else {
            segments.add(0L to durationMs)
        }
        currentSegment = 0
        isConverting = true
        convertButton.isEnabled = false
        progress.visibility = ProgressBar.VISIBLE
        progress.progress = 0
        exportNext(input, outputDir)
    }

    private fun exportNext(input: Uri, outputDir: File) {
        if (currentSegment >= segments.size) {
            isConverting = false
            convertButton.isEnabled = true
            progress.progress = 100
            progress.visibility = ProgressBar.GONE
            if (saveGalleryOption.isChecked) {
                saveOutputsToGallery()
            } else {
                status.text = "Export complete: ${outputFiles.size} clip(s). Files remain inside HD Status. Requested video bitrate: ${requestedBitrate / 1_000_000.0} Mbps."
            }
            return
        }

        val (startMs, endMs) = segments[currentSegment]
        val file = File(outputDir, "HDStatus_${System.currentTimeMillis()}_${currentSegment + 1}.mp4")
        val mediaItem = MediaItem.Builder()
            .setUri(input)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
            )
            .build()
        val videoEffects = if (useVertical) {
            listOf(Presentation.createForAspectRatio(9f / 16f, Presentation.LAYOUT_SCALE_TO_FIT))
        } else {
            emptyList()
        }
        val editedItem = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                outputFiles.add(file)
                currentSegment++
                progress.progress = (currentSegment * 100) / segments.size
                status.text = "Converted clip $currentSegment of ${segments.size}…"
                exportNext(input, outputDir)
            }

            override fun onError(
                composition: androidx.media3.transformer.Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                transformer = null
                isConverting = false
                convertButton.isEnabled = true
                file.delete()
                progress.visibility = ProgressBar.GONE
                status.text = "Conversion failed on clip ${currentSegment + 1}. Try a different video."
                Toast.makeText(this@MainActivity, exportException.errorCodeName, Toast.LENGTH_LONG).show()
            }
        }
        try {
            status.text = "Converting clip ${currentSegment + 1} of ${segments.size}…"
            val encoderFactory = DefaultEncoderFactory.Builder(this)
                .setRequestedVideoEncoderSettings(
                    VideoEncoderSettings.Builder()
                        .setBitrate(requestedBitrate)
                        .build()
                )
                .build()
            transformer = Transformer.Builder(this)
                .setEncoderFactory(encoderFactory)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(listener)
                .build()
            transformer?.start(editedItem, file.absolutePath)
        } catch (e: Exception) {
            transformer = null
            isConverting = false
            convertButton.isEnabled = true
            file.delete()
            status.text = "Could not start conversion. Try another video."
        }
    }


    private fun saveOutputsToGallery() {
        val files = outputFiles.filter { it.exists() }
        if (files.isEmpty()) {
            status.text = "Conversion finished, but no output files were found."
            return
        }
        var saved = 0
        var failed = 0
        for (file in files) {
            var insertedUri: Uri? = null
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HD Status")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }
                insertedUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Gallery could not create a media entry")
                contentResolver.openOutputStream(insertedUri, "w").use { output ->
                    if (output == null) throw IllegalStateException("Could not open Gallery destination")
                    file.inputStream().use { input -> input.copyTo(output) }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    contentResolver.update(insertedUri, done, null, null)
                }
                saved++
            } catch (_: Exception) {
                failed++
                if (insertedUri != null) {
                    try { contentResolver.delete(insertedUri, null, null) } catch (_: Exception) { }
                }
            }
        }
        status.text = when {
            saved == files.size -> "Conversion complete. Saved $saved video(s) to Gallery → Movies/HD Status."
            saved > 0 -> "Saved $saved of ${files.size} video(s) to Gallery. Some could not be saved."
            else -> "Conversion complete, but Gallery save failed. Use Share Converted Clips to access your videos."
        }
        if (failed > 0) Toast.makeText(this, "Gallery save failed for $failed file(s).", Toast.LENGTH_LONG).show()
    }

    private fun shareOutputs() {
        val files = outputFiles.filter { it.exists() }
        if (files.isEmpty()) {
            status.text = "Convert a video first."
            return
        }
        try {
            val uris = ArrayList(files.map {
                FileProvider.getUriForFile(this, "$packageName.fileprovider", it)
            })
            val intent = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, uris[0])
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "video/mp4"
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                }
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "Share to WhatsApp or another app"))
        } catch (_: Exception) {
            status.text = "Could not open the share menu."
        }
    }

    override fun onDestroy() {
        if (isConverting) {
            transformer?.cancel()
            transformer = null
        }
        super.onDestroy()
    }
}
