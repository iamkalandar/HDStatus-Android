package com.hdstatus.app

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var verticalOption: CheckBox
    private lateinit var splitOption: CheckBox
    private lateinit var compressOption: CheckBox
    private lateinit var convertButton: Button
    private var selectedUri: Uri? = null
    private var selectedMusicUri: Uri? = null
    private var transformer: Transformer? = null
    private var isConverting = false
    private val outputFiles = mutableListOf<File>()
    private var segments = mutableListOf<Pair<Long, Long>>()
    private var currentSegment = 0
    private var durationMs = 0L
    private var sourceWidth = 1280
    private var sourceHeight = 720
    private var sourceBitrate = 8_000_000
    private var requestedBitrate = 8_000_000
    private var useVertical = false

    private val musicPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            selectedMusicUri = uri
            status.text = "Audio file selected. This build does not yet mix it into the exported video."
        }
    }

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            outputFiles.clear()
            status.text = "Video selected. Original resolution will be retained unless 9:16 is enabled. HD bitrate will be requested for export."
        } else {
            status.text = "No video selected."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 24)
        }
        val scroll = ScrollView(this).apply { addView(page) }
        val title = TextView(this).apply {
            text = "HD Status"
            textSize = 32f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 4)
        }
        val subtitle = TextView(this).apply {
            text = "WhatsApp-focused export • 60-second clips • Share"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 8)
        }
        val developer = TextView(this).apply {
            text = "Developed by Kalander"
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        }
        status = TextView(this).apply {
            text = "Choose a video to make WhatsApp-ready MP4 clips."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = ProgressBar.GONE
        }
        verticalOption = CheckBox(this).apply {
            text = "Vertical 9:16 (may reframe video)"
            isChecked = false
        }
        splitOption = CheckBox(this).apply {
            text = "Split into 60-second clips"
            isChecked = true
        }
        compressOption = CheckBox(this).apply {
            text = "Smaller file (lower bitrate, may reduce detail)"
            isChecked = false
        }
        val chooseButton = Button(this).apply {
            text = "1. Choose Video"
            setOnClickListener { if (!isConverting) picker.launch("video/*") }
        }
        convertButton = Button(this).apply {
            text = "2. Convert Video"
            setOnClickListener { beginConversion() }
        }
        val musicButton = Button(this).apply {
            text = "3. Choose Background Music"
            setOnClickListener {
                if (!isConverting) musicPicker.launch(arrayOf("audio/*"))
            }
        }
        val freeMusicButton = Button(this).apply {
            text = "Free Music Libraries"
            setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("Free music for videos")
                    .setItems(arrayOf("Pixabay Music", "YouTube Audio Library", "Mixkit Music")) { _, which ->
                        val url = when (which) {
                            0 -> "https://pixabay.com/music/"
                            1 -> "https://www.youtube.com/audiolibrary"
                            else -> "https://mixkit.co/free-stock-music/"
                        }
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    }.show()
            }
        }
        val shareButton = Button(this).apply {
            text = "4. Share Converted Clips"
            setOnClickListener { shareOutputs() }
        }
        val aboutButton = Button(this).apply {
            text = "About / Contact Kalander"
            setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("About HD Status")
                    .setMessage(
                        "HD Status\nVideo converter for WhatsApp Status\n\n" +
                            "Developer: Kalander\nContact: +91-8050152388\n\n" +
                            "Conversion runs on your phone. Supported formats depend on device codecs."
                    )
                    .setPositiveButton("OK", null)
                    .setNeutralButton("WhatsApp contact") { _, _ ->
                        val contact = "https://wa.me/918050152388"
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(contact)))
                    }
                    .show()
            }
        }
        listOf(title, subtitle, developer, status).forEach { page.addView(it, matchWrap()) }
        page.addView(progress, matchWrap())
        page.addView(verticalOption, matchWrap())
        page.addView(splitOption, matchWrap())
        page.addView(compressOption, matchWrap())
        listOf(chooseButton, convertButton, musicButton, freeMusicButton, shareButton, aboutButton).forEach {
            page.addView(it, matchWrap())
        }
        setContentView(scroll)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun beginConversion() {
        val input = selectedUri
        if (input == null) {
            status.text = "Please choose a video first."
            return
        }
        if (isConverting) return

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, input)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            sourceWidth = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: 1280
            sourceHeight = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: 720
            // Request a quality-oriented bitrate based on the original resolution.
            // Android device encoders may adjust this request if their hardware requires it.
            val maxDimension = maxOf(sourceWidth, sourceHeight)
            sourceBitrate = when {
                maxDimension >= 3000 -> 24_000_000
                maxDimension >= 1900 -> 14_000_000
                maxDimension >= 1200 -> 8_000_000
                maxDimension >= 700 -> 5_000_000
                else -> 2_500_000
            }
        } catch (_: Exception) {
            durationMs = 0L
        } finally {
            try { retriever.release() } catch (_: Exception) { }
        }
        if (durationMs <= 0L) {
            status.text = "Could not read this video's duration. Try another video."
            return
        }

        val outputDir = File(filesDir, "converted")
        if (!outputDir.exists() && !outputDir.mkdirs()) {
            status.text = "Could not create output folder."
            return
        }
        outputFiles.clear()
        segments.clear()
        useVertical = verticalOption.isChecked
        requestedBitrate = if (compressOption.isChecked) (sourceBitrate * 0.60).toInt().coerceAtLeast(1_000_000) else sourceBitrate
        val segmentLength = 60_000L
        if (splitOption.isChecked && durationMs > segmentLength) {
            var start = 0L
            while (start < durationMs) {
                val end = minOf(start + segmentLength, durationMs)
                segments.add(start to end)
                start = end
            }
        } else {
            segments.add(0L to durationMs)
        }
        currentSegment = 0
        isConverting = true
        convertButton.isEnabled = false
        progress.visibility = ProgressBar.VISIBLE
        progress.progress = 0
        exportNext(input, outputDir)
    }

    private fun exportNext(input: Uri, outputDir: File) {
        if (currentSegment >= segments.size) {
            isConverting = false
            convertButton.isEnabled = true
            progress.progress = 100
            status.text = "Export complete: ${outputFiles.size} clip(s). Requested bitrate: ${requestedBitrate / 1_000_000} Mbps. This is quality-preserving re-encoding, not AI enhancement. Music mixing is not included in this build."
            return
        }

        val (startMs, endMs) = segments[currentSegment]
        val file = File(outputDir, "HDStatus_${System.currentTimeMillis()}_${currentSegment + 1}.mp4")
        val mediaItem = MediaItem.Builder()
            .setUri(input)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
            )
            .build()
        val videoEffects = if (useVertical) {
            listOf(Presentation.createForAspectRatio(9f / 16f, Presentation.LAYOUT_SCALE_TO_FIT))
        } else {
            emptyList()
        }
        val editedItem = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                outputFiles.add(file)
                currentSegment++
                progress.progress = (currentSegment * 100) / segments.size
                status.text = "Converted clip $currentSegment of ${segments.size}…"
                exportNext(input, outputDir)
            }

            override fun onError(
                composition: androidx.media3.transformer.Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                transformer = null
                isConverting = false
                convertButton.isEnabled = true
                file.delete()
                progress.visibility = ProgressBar.GONE
                status.text = "Conversion failed on clip ${currentSegment + 1}. Try a different video."
                Toast.makeText(this@MainActivity, exportException.errorCodeName, Toast.LENGTH_LONG).show()
            }
        }
        try {
            status.text = "Converting clip ${currentSegment + 1} of ${segments.size}…"
            val encoderFactory = DefaultEncoderFactory.Builder(this)
                .setRequestedVideoEncoderSettings(
                    VideoEncoderSettings.Builder()
                        .setBitrate(requestedBitrate)
                        .build()
                )
                .build()
            transformer = Transformer.Builder(this)
                .setEncoderFactory(encoderFactory)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(listener)
                .build()
            transformer?.start(editedItem, file.absolutePath)
        } catch (e: Exception) {
            transformer = null
            isConverting = false
            convertButton.isEnabled = true
            file.delete()
            status.text = "Could not start conversion. Try another video."
        }
    }

    private fun shareOutputs() {
        val files = outputFiles.filter { it.exists() }
        if (files.isEmpty()) {
            status.text = "Convert a video first."
            return
        }
        try {
            val uris = ArrayList(files.map {
                FileProvider.getUriForFile(this, "$packageName.fileprovider", it)
            })
            val intent = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, uris[0])
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "video/mp4"
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                }
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "Share to WhatsApp or another app"))
        } catch (_: Exception) {
            status.text = "Could not open the share menu."
        }
    }

    override fun onDestroy() {
        if (isConverting) {
            transformer?.cancel()
            transformer = null
        }
        super.onDestroy()
    }
}
