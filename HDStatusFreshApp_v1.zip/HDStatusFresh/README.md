# HD Status — Fresh Project

This is a clean Android Kotlin project replacing the previous broken project source.

Included in this first fresh build:
- Dark four-column video gallery using Android MediaStore
- Video thumbnails and duration labels
- Tap a thumbnail to select and prepare a video
- Open-document video picker fallback
- Share selected videos using Android's share sheet
- Menu and simple dark UI

Not included yet:
- Video re-encoding/compression
- 60-second splitting
- Music mixing, trim/text/sticker editor
- Photo, Albums, and AI tools

This project deliberately starts with a minimal stable foundation to avoid carrying forward the previous compilation errors. Build it with Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Java 17, and Android SDK 35.
