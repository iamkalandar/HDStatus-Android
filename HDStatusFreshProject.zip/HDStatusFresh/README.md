# HD Status

Android video converter by Kalander. Package: `com.hdstatus.app`.

## Features
- Pick a video using Android's system picker.
- Convert supported input video to MP4 with H.264/AAC output.
- Resize output for compression (720p landscape/default or 9:16 vertical).
- Optionally split longer videos into 30-second MP4 clips.
- Share generated clips using Android's share sheet, including WhatsApp.
- About screen lists developer Kalander and contact number +91-8050152388.

## Build
Push to `main` or run the **Build HD Status APK** workflow manually. Download the `HD-Status-debug-apk` artifact.

Note: Media3 uses codecs available on the device, so not every unusual codec/container can be decoded. Vertical mode fits the video into a 9:16 frame; it does not aggressively crop the sides. Splits are 30-second clips, but WhatsApp's current limits may vary by account/region/app version.
